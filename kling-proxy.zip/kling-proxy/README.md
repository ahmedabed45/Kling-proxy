# Kling Proxy — Vercel Backend

## الهدف
Vercel function بتشتغل كـ backend proxy للـ Kling API
بتحل مشكلة CORS وتخلي الـ React app يتكلم مع Kling بدون مشاكل

## خطوات الـ Deploy (5 دقايق)

### 1. GitHub
- اعمل repo جديد على github.com
- ارفع الملفات دي (api/kling.js + vercel.json + package.json)

### 2. Vercel
- روح على vercel.com وسجّل بـ GitHub (مجاني)
- New Project → Import الـ repo
- اضغط Deploy

### 3. Environment Variables
في Vercel Dashboard → Settings → Environment Variables:
```
KLING_ACCESS_KEY = مفتاحك الجديد
KLING_SECRET_KEY = السر الجديد
```

### 4. الـ URL
بعد الـ deploy هيديك URL زي:
`https://kling-proxy-xxx.vercel.app`

حطه في الـ React app في خانة Vercel URL

## الـ API Endpoints
- POST `/api/kling` — بيعمل video task
- GET `/api/kling?task_id=xxx` — بيجيب الـ status

## ملاحظة أمان
الـ Keys بتتخزن في Vercel env vars فقط — مش في الكود
