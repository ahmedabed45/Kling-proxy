import crypto from 'crypto';

function makeJWT(accessKey, secretKey) {
  const enc = s => Buffer.from(s).toString('base64url');
  const header = enc(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const now = Math.floor(Date.now() / 1000);
  const payload = enc(JSON.stringify({ iss: accessKey, exp: now + 1800, nbf: now - 5 }));
  const data = `${header}.${payload}`;
  const sig = crypto.createHmac('sha256', secretKey).update(data).digest('base64url');
  return `${data}.${sig}`;
}

export default async function handler(req, res) {
  // CORS — يسمح لأي domain
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') return res.status(200).end();

  const AK = process.env.KLING_ACCESS_KEY;
  const SK = process.env.KLING_SECRET_KEY;
  if (!AK || !SK) return res.status(500).json({ error: 'Keys not configured in Vercel env vars' });

  const token = makeJWT(AK, SK);
  const BASE = 'https://api.klingai.com';

  try {
    if (req.method === 'POST') {
      // Create video task
      const { prompt, duration, aspect_ratio, mode, model_name } = req.body;
      const r = await fetch(`${BASE}/v1/videos/text2video`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ model_name, prompt, duration: parseInt(duration), aspect_ratio, mode })
      });
      const data = await r.json();
      return res.status(r.status).json(data);
    }

    if (req.method === 'GET') {
      // Poll task status
      const { task_id } = req.query;
      if (!task_id) return res.status(400).json({ error: 'task_id required' });
      const r = await fetch(`${BASE}/v1/videos/text2video/${task_id}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      const data = await r.json();
      return res.status(r.status).json(data);
    }

    return res.status(405).json({ error: 'Method not allowed' });
  } catch (e) {
    return res.status(500).json({ error: e.message });
  }
}
